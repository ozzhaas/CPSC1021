
//Defines the header file to make sure that it has not been defined once previously//
#ifndef FUNCTIONS_H
#define FUNCTIONS_H


//Function prototypes//
void sizeOfName(char** name);
void printSizeOfName(int *firstCount, int *lastCount, char** name);
void reverseString(int *first, int *last, char** name);



#endif
