/* Kellen Haas
CPSC 1021
Sec. 001 - F19
10/08/19
mkhaas@clemson.edu
Damion*/

//SOOOO many seg faults :(
//It reads in input fine and outputs it to the out.txt file when I only use main
//as soon as I use my functions it freaks out. I'm sorry for wasting your time.

#include "functions.h"

int main (int argc, char* argv[]) {

    int numStuds = 0;
    string line;
    if (argc != 3){
        cout << "Error needs two files (Input and Output)" << endl;
        return -1;
    }

    else {
        ifstream input;
        input.open(argv[1]);
        ofstream output;
        output.open(argv[2]);


        while (getline(input, line)) {
            //output << line << endl;
            numStuds++;
        }

        input.close();

        input.open(argv[1]);
        Student* stud = (Student*)malloc(numStuds * sizeof(Student));

        if(!input.is_open()){
            _Exit(-1);
        }
        for(int i = 0; i < numStuds; i++){
            readData(input, stud, i);
        }
        for (int j = 0; j < numStuds; j++) {
            printData(output, stud, j);
        }


        input.close();
        output.close();
        free(stud);
    }
}
