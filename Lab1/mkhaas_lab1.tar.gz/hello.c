
#include <stdio.h>

int main() {

    printf("I am pumped to learn more about C and C++\n");

    return 0;

}
